#include "sma_crossover_strategy.h"
#include <vector>
#include <numeric>

using namespace std;

double calculate_sma(const vector<double> &data, int start, int period) {
    double sum = 0.0;
    for (int i = start - period + 1; i <= start; ++i) {
        sum += data[i];
    }
    return sum / period;
}

TradeResult run_sma_crossover_strategy(const vector<Candle> &candles, double profit_threshold) {
    vector<double> closes;
    for (const auto &candle : candles)
        closes.push_back(candle.close);

    vector<int> sma_positions(closes.size(), 0);

    double entry_price = 0.0;
    bool in_position = false;
    double total_return = 0.0;
    int total_trades = 0, profitable_trades = 0;

    for (size_t i = 200; i < closes.size(); ++i) {
        double sma50 = calculate_sma(closes, i, 50);
        double sma200 = calculate_sma(closes, i, 200);

        if (!in_position && sma50 > sma200) {
            sma_positions[i] = 1; // Buy signal
            entry_price = closes[i];
            in_position = true;
        }
        else if (in_position && sma50 < sma200) {
            sma_positions[i] = -1; // Sell signal
            double ret = (closes[i] - entry_price) / entry_price;
            total_return += ret;
            if (ret > profit_threshold) profitable_trades++;
            total_trades++;
            in_position = false;
        }
        else {
            sma_positions[i] = 0;
        }
    }

    if (in_position) {
        double final_price = closes.back();
        double ret = (final_price - entry_price) / entry_price;
        total_return += ret;
        if (ret > profit_threshold) profitable_trades++;
        total_trades++;
    }

    double success_rate = total_trades ? (profitable_trades * 100.0 / total_trades) : 0;
    double avg_return = total_trades ? (total_return * 100.0 / total_trades) : 0;

    return {success_rate, avg_return, total_trades, sma_positions};
}

