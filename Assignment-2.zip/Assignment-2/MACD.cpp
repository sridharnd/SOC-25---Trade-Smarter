#include "macd_strategy.h"
#include <vector>
#include <cmath>

using namespace std;

double calculate_ema(const vector<double> &data, int index, int period) {
    double multiplier = 2.0 / (period + 1);
    double ema = data[index - period];
    for (int i = index - period + 1; i <= index; ++i) {
        ema = (data[i] - ema) * multiplier + ema;
    }
    return ema;
}

TradeResult run_macd_strategy(const vector<Candle> &candles, double profit_threshold) {
    vector<double> closes;
    for (const auto &candle : candles)
        closes.push_back(candle.close);

    vector<int> macd_positions(closes.size(), 0);

    double total_return = 0.0;
    int total_trades = 0, profitable_trades = 0;
    bool in_position = false;
    double entry_price = 0.0;

    for (size_t i = 35; i < closes.size(); ++i) {
        double ema12 = calculate_ema(closes, i, 12);
        double ema26 = calculate_ema(closes, i, 26);
        double macd = ema12 - ema26;

        vector<double> macd_line;
        for (size_t j = i - 8; j <= i; ++j) {
            macd_line.push_back(calculate_ema(closes, j, 12) - calculate_ema(closes, j, 26));
        }

        double signal = calculate_ema(macd_line, macd_line.size() - 1, 9);

        if (!in_position && macd > signal) {
            macd_positions[i] = 1; // Buy signal
            entry_price = closes[i];
            in_position = true;
        }
        else if (in_position && macd < signal) {
            macd_positions[i] = -1; // Sell signal
            double ret = (closes[i] - entry_price) / entry_price;
            total_return += ret;
            if (ret > profit_threshold) profitable_trades++;
            total_trades++;
            in_position = false;
        }
        else {
            macd_positions[i] = 0;
        }
    }

    if (in_position) {
        double final_price = closes.back();
        double ret = (final_price - entry_price) / entry_price;
        total_return += ret;
        if (ret > profit_threshold) profitable_trades++;
        total_trades++;
    }

    double success_rate = total_trades ? (profitable_trades * 100.0 / total_trades) : 0;
    double avg_return = total_trades ? (total_return * 100.0 / total_trades) : 0;

    return {success_rate, avg_return, total_trades, macd_positions};
}

